#include <iostream>
#include <cstring>
#include <cmath>
#include <stdlib.h>
#include <stdio.h>
using namespace std;
int main(){
   
   int row;
   int column;
   cout << "Enter rows and columns number" << endl;
   cin >> row >> column;
   cout << row << " " << column << endl;
   //2D array
   int **matrix ;
   int **transposeMatrix;
   //allocation
    matrix=new int*[row];
    for (int i=0;i<row;i++){
      matrix[i]=new int [column];
        }
    
     for(int i = 0; i < row; ++i){
        for(int j = 0; j < column; ++j){
        cin >> matrix[i][j];
            }
           }
 
       cout << endl << "Entered  Matrix: " << endl;
     for(int i=0;i<row;i++){
        for(int j=0;j< column;j++){
        cout <<  matrix[i][j] << " " ;
         }
         cout << "\n" ;
         }
      
      //allocation  
        transposeMatrix=new int*[column];
             for(int j=0;j<column;j++){
               transposeMatrix[j]=new int[row];
             }


       for(int i=0;i<row;i++){
       for(int j=0;j< column;j++){
           int temp=matrix[i][j];
           matrix[i][j]=transposeMatrix[j][i];
           transposeMatrix[j][i]=temp;
           }
         }
       cout << endl << "Transpose of Matrix: " << endl;
    
        for(int i=0; i<column; ++i){
            for(int j=0; j<row; ++j)
            {
                cout << transposeMatrix[i][j] << " "; 
             }
            cout << "\n" ;
        }
           
         //deallocation
             delete  [] matrix;
             matrix=0;
             delete [] transposeMatrix;
             transposeMatrix=0;
 return 0;
}
 
