#include <iostream>
#include <cstring>
#include <cmath>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

int main(int argc,char *argv[])
 {
       
         if(argc < 2 ){
          cerr << "Usage: " << argv[0]
         << " <no commandline argument>" << endl;
             return EXIT_FAILURE;
             }
    
       int multresult=1;
       int addresult=0;
       char theOperator = argv[1][0];
       int numbers;
   
     
       if(theOperator=='x'){
          if(argc<3){
            cout << " <no numbers for multiplication>" << "\n" << multresult  << endl;
               return multresult;
               }
 
          else{
             for(int i=2;i<argc ;i++){
              numbers=atoi(argv[i]);
              multresult=multresult*numbers;
             }
           cout << multresult << endl;
            }
          }
            
       else  if(theOperator=='+'){
             if(argc<3){
               cout << "<no numbers for adding>" << "\n" << addresult  << endl;
               return addresult;
                  }
             else{
              for(int i=2;i<argc;i++){
               numbers=atoi(argv[i]);
               addresult=addresult+numbers;
               }
            cout << addresult << endl;
               }
             }
        
       else{
             fprintf(stderr, "No operator for calculation");
            exit(0);
           }
    return 0;
}
